/**
 * 
 */
package test;

import static org.junit.jupiter.api.Assertions.*;
import gestion.Gestion;
import utilidades.Utilidades;
import clasesBasicas.UsuarioImpl;
import org.junit.jupiter.api.Test;

/**
 * @author Angela Vazquez
 *
 */
class TestJUnitGestion {

	/**
	 * Test method for {@link gestion.Gestion#obtenerEdad(clasesBasicas.UsuarioImpl)}.
	 */
	@Test
	void testObtenerEdad() {
		Gestion g = new Gestion();
		Utilidades u = new Utilidades();
		UsuarioImpl usuario = u.cargarUsuario("randomkwiz", "123456789");
		int edad = g.obtenerEdad(usuario);
		
		assertTrue(edad == 1);
	}

}
